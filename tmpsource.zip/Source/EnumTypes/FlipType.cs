﻿namespace AcornPad.Common
{
    public enum FlipType
    {
        FlipNone = 0,
        FlipX,
        FlipY
    }
}