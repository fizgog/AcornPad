﻿using System;

namespace AcornPad.Common
{
    [Serializable]
    public enum ExportFormatType
    {
        BeebASM = 0,
        CC65 = 1
    }
}