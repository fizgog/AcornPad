﻿using System;

namespace AcornPad.Common
{
    [Serializable]
    public enum MachineType
    {
        BBC = 0,
        Atom = 1
    }
}