﻿using System;

namespace AcornPad.Common
{
    [Serializable]
    public enum CompressionType
    {
        None = 0,
        Run_length = 1
    }
}