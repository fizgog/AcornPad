﻿namespace AcornPad.Common
{
    public enum RotateType
    {
        RotateNone = 0,
        Rotate90,
        Rotate180,
        Rotate270
    }
}