﻿using System;

namespace AcornPad.Common
{
    [Serializable]
    public enum LayoutType
    {
        Row = 0,
        Column = 1
    }
}