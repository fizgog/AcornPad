﻿using System;

namespace AcornPad.Common
{
    [Serializable]
    public enum BitsPerPixelType
    {
        PixelDepth2 = 2,
        PixelDepth4 = 4,
        PixelDepth8 = 8
    }
}