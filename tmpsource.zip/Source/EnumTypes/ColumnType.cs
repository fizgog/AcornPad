﻿using System;

namespace AcornPad.Common
{
    [Serializable]
    public enum ColumnType
    {
        One = 1,
        Two = 2,
        Four = 4,
        Eight = 8
    }
}