﻿namespace AcornPad.Common
{
    public enum ShiftType
    {
        ShiftNone = 0,
        ShiftLeft,
        ShiftRight,
        ShiftUp,
        ShiftDown
    }
}